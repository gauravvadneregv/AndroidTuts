package com.example.recyclerviewdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Country> countryList;
    MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayoutManager llm = new LinearLayoutManager(getApplicationContext());
        GridLayoutManager glm = new GridLayoutManager(getApplicationContext(), 3);

        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(llm);

        countryList = new ArrayList<>();

        countryList.add(new Country("India", R.drawable.indian_flag));
        countryList.add(new Country("South Africa", R.drawable.southafrica_flag));
        countryList.add(new Country("USA", R.drawable.usa_flag));
        countryList.add(new Country("Canada", R.drawable.canada_flag));
        countryList.add(new Country("France", R.drawable.france_flag));

        myAdapter = new MyAdapter(getApplicationContext(), MainActivity.this, countryList);
        recyclerView.setAdapter(myAdapter);
        Collections.sort(countryList, new Comparator<Country>() {
            @Override
            public int compare(Country o1, Country o2) {
                return o1.countryName.compareTo(o2.countryName);
            }
        });
        myAdapter.notifyDataSetChanged();
    }
}