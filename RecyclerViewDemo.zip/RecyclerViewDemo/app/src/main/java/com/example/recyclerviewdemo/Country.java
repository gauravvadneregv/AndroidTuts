package com.example.recyclerviewdemo;

public class Country {

    public String countryName;
    public int countryImage;

    public Country(String countryName, int countryImage) {
        this.countryName = countryName;
        this.countryImage = countryImage;
    }
}
