package com.example.multiscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class DisplayActivity extends AppCompatActivity {

    TextView nameText, emailText, phoneText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        Intent intent = getIntent();

        String name1 = intent.getStringExtra("nm");
        String email = intent.getStringExtra("email");
        String phone = intent.getStringExtra("phone");

        emailText = findViewById(R.id.email_text);

        emailText.setText(name1 + "\n" + email + "\n" + phone);
    }
}