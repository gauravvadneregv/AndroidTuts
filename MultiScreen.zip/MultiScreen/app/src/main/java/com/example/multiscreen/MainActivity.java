package com.example.multiscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button submitBtn;

    EditText nameInput, emailInput, phoneInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameInput = findViewById(R.id.editTextTextPersonName);
        emailInput = findViewById(R.id.editTextTextEmailAddress);
        phoneInput = findViewById(R.id.editTextPhone);

        submitBtn = findViewById(R.id.submit_btn);

        submitBtn.setOnClickListener(v -> {
            String name1 = nameInput.getText().toString();
            String email = emailInput.getText().toString();
            String phone = phoneInput.getText().toString();

            Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
            intent.putExtra("email", email);
            intent.putExtra("nm", name1);
            intent.putExtra("phone", phone);
            startActivity(intent);
        });
    }
}